/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 262401
#define R_NICK "Kick Things"
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "4"
#define R_MINOR  "1.1"
#define R_STATUS ""
#define R_YEAR   "2021"
#define R_MONTH  "08"
#define R_DAY    "10"
#define R_SVN_REVISION 80725
#define R_FILEVERSION    4,11,80725,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
